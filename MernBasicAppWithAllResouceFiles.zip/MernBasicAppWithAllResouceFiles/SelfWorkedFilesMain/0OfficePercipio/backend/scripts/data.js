export const users = [
  { user: 'joe', city: 'vancouver' },
  { user: 'charlie', city: 'phoenix' },
  { user: 'simon', city: 'boston' },
  { user: 'teresa', city: 'toronto' },
  { user: 'sara', city: 'new york' },
  { user: 'dalton', city: 'edmonton' },
  { user: 'sandy', city: 'new york' },
  { user: 'ambreen', city: 'los angeles' },
];

export const courses = [
  { name: 'intro to mern', weight: 10, images: [] },
  { name: 'intro to mongodb', weight: 10, images: [] },
  { name: 'intro to node', weight: 10, images: [] },
  { name: 'advanced mern', weight: 20, images: [] },
  { name: 'intro to FSD', weight: 10, images: [] },
  { name: 'advanced node', weight: 20, images: [] },
];
