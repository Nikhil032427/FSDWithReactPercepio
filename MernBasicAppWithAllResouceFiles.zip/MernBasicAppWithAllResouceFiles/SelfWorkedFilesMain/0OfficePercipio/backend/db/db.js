import mongoose from 'mongoose';
//mongoose.connect('mongodb://localhost:27017/test', { useNewUrlParser: true });
mongoose.set('strictQuery', true);
const options = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  serverSelectionTimeoutMS: 5000,
  autoIndex: false, // Don't build indexes
  maxPoolSize: 10, // Maintain up to 10 socket connections
  serverSelectionTimeoutMS: 5000, // Keep trying to send operations for 5 seconds
  socketTimeoutMS: 45000, // Close sockets after 45 seconds of inactivity
  family: 4 // Use IPv4, skip trying IPv6
}
mongoose.connect('mongodb://localhost:27017/test', options);
//mongoose.set('useFindAndModify', false);

// mongoose.connect('mongodb://127.0.0.1:27017/test', {
//     //  userNewUrlParser:true,
//     useUnifiedTopology: true
// }).then(() => {
//     console.log('Connected!!!!!');
// }).catch((e) => {
//     console.log(e);
// });



const db = mongoose.connection;

db.on('error', (error) => {
  console.error(error);
});

db.once('open', () => {
  console.log('Database connection open!');
});

export default db;
