const users = [
  {id: '1000', username: 'joe', role: 'instructor'}, 
  {id: '1001', username: 'sara', role: 'student'},
  {id: '1002', username: 'bill', role: 'student'}
];
export default users;