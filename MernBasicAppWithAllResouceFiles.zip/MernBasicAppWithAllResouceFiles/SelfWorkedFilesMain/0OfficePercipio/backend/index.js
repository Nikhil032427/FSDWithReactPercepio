import express from 'express';
import users from "./mocks/users";
import bodyParser from 'body-parser';
//import { courseRoutes } from "./routes/courses";
const courseRoutes = require('./routes/courses');
//import { userRoutes } from "./routes/users";
const userRoutes = require('./routes/users');
import {db} from "./db/db";
import  cors  from "cors";


const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
const port = 80;
courseRoutes.default(app);
userRoutes.default(app);
// courseRoutes(app);
// userRoutes(app);

app.listen(port,()=>{
    console.log(`express is listening on ${port} !!!`)
});